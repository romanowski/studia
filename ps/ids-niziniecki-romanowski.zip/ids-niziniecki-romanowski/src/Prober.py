import psutil

class Prober(object):

	def get_data(self):
		
		data = {
			'cpu_usage': psutil.cpu_percent()/100,
			'disc_usage': psutil.disk_usage('/').percent/100,
			'ram_usage': psutil.virtual_memory().percent/100,
			'swap_usage': psutil.swap_memory().percent/100,
			'processes': list(psutil.process_iter()).__len__()/1000,
			'users': psutil.get_users().__len__()/100
		}
		
		return data
