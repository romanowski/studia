#!/usr/bin/python

import sys
from PyQt4 import QtGui, QtCore
from Prober import Prober
from Expert import Expert
import time

class DiagnoseThread(QtCore.QThread):
	
	def __init__(self, expert, prober):
		QtCore.QThread.__init__(self)
		self.expert = expert
		self.prober = prober

	def run(self):
		while 1:
			print "tuuuu"
			if self.expert.isAnomaly(self.prober.get_data()):
				self.emit(QtCore.SIGNAL('update()'))
			time.sleep(5)
		
class Start(QtGui.QWidget):
	
	def __init__(self):
		super(Start, self).__init__()
		self.initUI()
		self.prober = Prober()
		self.expert = Expert()
		self.diagnosing = False
		
	def initUI(self):
		self.resize(250, 150)
		self.center()
		
		self.setLayout(self.create_two_buttons_layout('Ucz', self.on_learn_clicked, 'Diagnozuj', self.on_diagnose_clicked)) 
		
		self.setWindowTitle('IDS Y-means')
		self.show()
		
		self.create_sys_tray()
		
	def on_learn_clicked(self):
		dialog = QtGui.QDialog(self)
		dialog.setWindowTitle(self.tr('Uczenie'))
		dialog.setLayout(self.create_two_buttons_layout('OK', self.on_learn_ok_clicked, 'Anomalia', self.on_learn_anomaly_clicked))
		dialog.exec_()
		
	def on_diagnose_clicked(self):
		self.hide();
		if self.diagnosing == False:
			self.diagnosing = True
			self.diagnoseThread = DiagnoseThread(self.expert, self.prober)
			self.connect(self.diagnoseThread, QtCore.SIGNAL("update()"), self.anomalyDetected)
			self.diagnoseThread.start()
	
	def anomalyDetected(self):
		self.show()
		dialog = QtGui.QDialog(self)
		dialog.setWindowTitle(self.tr('Anomalia!'))
		
		label = QtGui.QLabel('Wykryto anomalie!', self)
		
		hbox = QtGui.QHBoxLayout()
		hbox.addWidget(label)
		
		dialog.setLayout(hbox)
		dialog.exec_()
	
	def on_learn_ok_clicked(self):
		self.expert.putItem(self.prober.get_data(), 0)
		
	def on_learn_anomaly_clicked(self):
		self.expert.putItem(self.prober.get_data(), 1)
	
	def create_two_buttons_layout(self, name1, action1, name2, action2):
		learn_button = QtGui.QPushButton(name1, self)
		learn_button.clicked.connect(action1)
		
		diagnose_button = QtGui.QPushButton(name2, self)
		diagnose_button.clicked.connect(action2)
		
		hbox = QtGui.QHBoxLayout()
		hbox.addWidget(learn_button)
		hbox.addWidget(diagnose_button)
		
		vbox = QtGui.QVBoxLayout()
		vbox.addLayout(hbox)
		vbox.addStretch(1)
		
		return vbox
	
	def create_sys_tray(self):
		self.sysTray = QtGui.QSystemTrayIcon(self)
		self.sysTray.setIcon(QtGui.QIcon('../assets/icon.png'))
		self.sysTray.setVisible(True)
		self.connect(self.sysTray, QtCore.SIGNAL('activated(QSystemTrayIcon::ActivationReason)'), self.on_sys_tray_activated)

	def on_sys_tray_activated(self, reason):
		self.show()
		
	def center(self):
		qr = self.frameGeometry()
		cp = QtGui.QDesktopWidget().availableGeometry().center()
		qr.moveCenter(cp)
		self.move(qr.topLeft())

if __name__ == '__main__':
	app = QtGui.QApplication(sys.argv)
	ex = Start()
	sys.exit(app.exec_())
