from sklearn import svm
import os
import time
import random
import math

		
def do_it(data):
		try:
			return float(data)
		except ValueError:
			return 0.0

class Expert(object):
	def __init__(self):
		self.baseDir = '../data'
		self.ala = 30;
		
		self.newData = file(self.baseDir + "/" + str(time.time()) + ".save", 'a')
		self.dataMap = ['cpu_usage', 'disc_usage', 'ram_usage','swap_usage','processes',	'users']
		self.train()

	def isAnomaly(self, data):
		
		if self.reqTrain:
			self.train();
			print "tuuuuuuuuuuuuuuuuuuuuuuuu"
		v =  map(lambda x: float(data[x]), self.dataMap)
		print "tuuuuuuuuuuuuuuuuuuuuuuuu"
		print "Wektor danych: " + str(v) + " rezultat: " + str(self.clf.predict(v))
	
		if self.clf.predict(v) > 0.5:
			print "ANOMALY!!!!!!!!! RUN AWAY, RUN!!!!!!!"
			return 1


	def putItem(self, data, isAnomaly):
		self.reqTrain = 1
		newLine = ''
		for d in self.dataMap:
			newLine = newLine + str(float(data[d])) + " "
		newLine = newLine + str(float(isAnomaly)) + '\n'
		print "new Data intem: " + newLine
		self.newData.write(newLine)

	def train(self):
		self.load()
		
		self.newData.close();
		self.newData = file(self.baseDir + "/" + str(time.time()) + ".save", 'a')
		
		trainData = []
		testData = []
		
		trainRes = []
		testRes = []
		
		for i in range(len(self.data)):
			if random.randint(0, 10) > 1:
				trainData.append(self.data[i])
				trainRes.append(self.res[i])
			else:
				testData.append(self.data[i])
				testRes.append(self.res[i])
						
		self.clf = svm.SVC(gamma=0.001, C=100.)
		self.clf.fit(trainData, trainRes)
		
		yesyes = 0.0
		nono = 0.0
		yesno = 0.0
		noyes = 0.0
		
		if len(testData) > 0:
			print "Rozmiar danych testowych: " + str(len(testData))
			for i in range(len(testData)):
				out = self.clf.predict(testData[i])
				if(math.fabs(out[0] - testRes[i]) < 0.5):
					if testRes[i]:
						yesyes = yesyes  + 1
					else:
						nono = nono  + 1
				else:
					if testRes[i]:
						noyes = noyes  + 1
					else:
						yesno = yesno  + 1
		
			yesyes = yesyes / len(testData)
			nono = nono / len(testData)

			yesno = yesno / len(testData)
			noyes = noyes / len(testData)
			
			print "##################### Trenowanie: ######################"
			print "YesYes: " + str(yesyes)
			print "NoNo: " + str(nono)
			print "YesNo " + str(yesno)
			print "NoYes " + str(noyes)
			print "########################################################"
			
	def load(self):
		self.data= []
		self.res = []
		for f in os.listdir(self.baseDir):
			raw_data = map(
				lambda line: map(
					do_it,
					line.split(" ")),  
				open(self.baseDir + "/" +f).readlines())
			for row in raw_data:
				self.data.append(row[:len(self.dataMap)])
				self.res.append(row[-1])

		if  len(self.data) < 1:
			self.data= [map(lambda x: 0, self.dataMap)]
			self.res = [0]
			
		print '############## Data loaded ###########################'
		


