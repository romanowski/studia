cd src
python Start.py
cd ..