a = 1456;
while 1:
	a = a / (1 + a)
	if a < 0.001:
		a = 12345
