public class UnSynchMain {
	public static void main(String[] args) {

		
		System.out.println("bez synch");
		
		final Couter counter = new Couter();

		Thread ins = new Thread(new Runnable() {

			@Override
			public void run() {
				long start = System.nanoTime();

				for (int i = 0; i < 1000 * 1000; i++) {
					counter.inc();
				}
				System.out.println("KONIEC: " + (System.nanoTime() - start));
			}
		});

		Thread dec = new Thread() {
			@Override
			public void run() {

				long start = System.nanoTime();

				for (int i = 0; i < 1000 * 1000; i++) {
					counter.dec();
				}
				System.out.println("KONIEC: " + (System.nanoTime() - start));
			}
		};
		ins.start();
		dec.start();
		
		System.out.println("_____________________");
		
		CouterSynchMain.main(args);

	}

}
