
public class SynchCounter extends Couter{

	@Override
	public void inc(){
		synchronized (this) {
			counter++;
			//System.out.println("inc: " + counter);
		}
		
	}
	
	@Override
	public void dec(){
		synchronized (this) {
			counter--;
			//System.out.println("dec: " + counter);
		}
	}
	
}
