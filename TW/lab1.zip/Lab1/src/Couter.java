public class Couter {

	int counter;

	public void inc(){

			counter++;
			//System.out.println("inc: " + counter);

		
	}
	
	public void dec(){

			counter--;
		//	System.out.println("dec: " + counter);

	}

}
