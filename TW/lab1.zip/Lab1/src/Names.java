
public class Names {
public static void main(String[] args) {
		
		final Couter counter = new SynchCounter();

		Thread ins = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					System.out.println(Thread.currentThread().getName());
				}
			}
		});

		Thread dec = new Thread() {
			@Override
			public void run() {
				while (true) {
					System.out.println(getName());
				}
			}
		};
		ins.start();
		dec.start();

	}

}
