﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <quantum.h>

COMPLEX_FLOAT a0 = 0.0f;
COMPLEX_FLOAT a1 = 1.0f;
int I = 1;
int O = 0;

void quantum_not(int target, quantum_reg *reg)
{
  quantum_matrix m = quantum_new_matrix(2, 2);
  
  m.t[0] = a0;  m.t[1] = a1;
  m.t[2] = a1;  m.t[3] = a0;
  
  quantum_gate1(target, m, reg);
  
  quantum_delete_matrix(&m);
}

void quantum_uf (int f, int input, int output, quantum_reg *reg)
{
  quantum_matrix m = quantum_new_matrix(2, 2);

  switch(f)
  {
    case 0:
    break;
    
    case 1:
      quantum_cnot(input, output, reg);
    break;
    
    case 2:
      quantum_not(output, reg);
      quantum_cnot(input, output, reg);
    break;
    
    case 3:
      quantum_not(output, reg);
    break;
  }
  
  quantum_delete_matrix(&m);
}

int main ()
{
  int i, f;
  quantum_reg reg;

  srand(time(0));
  
  printf("=============== TEST DZIAŁANIA FUNKCJI Ufi ===============\n\n");
  
  for (f = 0; f < 4; ++f) {

    for (i = 0; i < 4; ++i) {

      reg = quantum_new_qureg(i, 2);
      
      printf("Uf%i", f); 
      quantum_print_qureg(reg);
      
      quantum_uf(f, I, O, &reg);
      
      printf(" =>"); 
      quantum_print_qureg(reg);
      
      quantum_delete_qureg(&reg);

    }
    
    printf("\n");
    
  }
  
  printf("====== TEST DZIAŁANIA ROZWIĄZANIA PROBLEMU DEUTSCHA ======\n\n");
  
  for (f = 0; f < 4; ++f) {
  
    reg = quantum_new_qureg(0, 2);
    
    quantum_not(0, &reg);
    quantum_not(1, &reg);
    
    quantum_hadamard(0, &reg);
    quantum_hadamard(1, &reg);
    
    quantum_uf(f, I, O, &reg);
    
    quantum_hadamard(1, &reg);
    
    printf("Uf%i\n", f); 
    quantum_print_qureg(reg);
    
    quantum_delete_qureg(&reg);
  
  }

  return 0;
}
