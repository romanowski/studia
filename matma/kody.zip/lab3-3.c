﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <quantum.h>

void quantum_uf (int a, quantum_reg *reg)
{
  int i;
  
  for (i = reg->width - 1; i; --i)
    if (a & 1 << (i - 1))
      quantum_cnot(i, 0, reg);
}

void printa(int a, int n)
{
  int i;
  
  printf("a = ");
  for (i = n - 1; i >= 0; --i)
    printf(a & 1 << i ? "1" : "0");
  printf("\n");
}

void quantum_uf_test(int a, int x, int n)
{
  quantum_reg reg = quantum_new_qureg(x << 1, n + 1);
  
  printa(a, n);
  
  printf("Uf"); 
  quantum_print_qureg(reg);
  
  quantum_uf(a, &reg);
  
  printf("=>"); 
  quantum_print_qureg(reg);
  
  quantum_delete_qureg(&reg);
}

int main ()
{
  int a, n, m;
  quantum_reg reg;

  srand(time(0));
  
  printf("=============== TEST DZIAŁANIA FUNKCJI Uf ================\n\n");
  
  quantum_uf_test(31, 31, 5);
  quantum_uf_test(30, 31, 5);
  quantum_uf_test(31, 30, 5);
  
  printf("========== ROZWIĄZANIE KLASYCZNE (n wywołań Uf) ==========\n\n");
  
  a = 1000;
  n = 10;
  
  printa(a, n);
  
  for (m = 0; m < n; ++m)
  {
    reg = quantum_new_qureg(1 << (m + 1), n + 1);
    
    quantum_uf(a, &reg);
    
    printf("a%i:", m);
    quantum_print_qureg(reg);
    
    quantum_delete_qureg(&reg);
  }
  
  printf("========= ROZWIĄZANIE KWANTOWE (1 wywołanie Uf) ==========\n\n");
  
  printa(a, n);
  
  reg = quantum_new_qureg(1, n + 1);
  
  for (m = 0; m < n + 1; ++m)
    quantum_hadamard(m, &reg);
    
  quantum_uf(a, &reg);
    
  for (m = 0; m < n + 1; ++m)
    quantum_hadamard(m, &reg);
  
  printf("a:");
  quantum_print_qureg(reg);
  
  quantum_delete_qureg(&reg);
    
  return 0;
}
