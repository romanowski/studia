#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <quantum.h>

int main ()
{
  int i;
  quantum_reg reg;
  MAX_UNSIGNED result;

  srand(time(0));

  for (i = 0; i < 8; ++i) {

    reg = quantum_new_qureg(i, 3);

    quantum_toffoli(2, 1, 0, &reg);

    result = quantum_measure(reg);
  
    printf("%i -> %i \n", i, result);

  }

 return 0;
}
