﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <quantum.h>
#include <math.h>

#define PI 3.14159265

void quantum_w(int target, quantum_reg *reg)
{
  quantum_matrix m = quantum_new_matrix(2, 2);
  
  m.t[0] =  sqrt(2. / 3);  m.t[1] = -sqrt(1. / 3);
  m.t[2] =  sqrt(1. / 3);  m.t[3] =  sqrt(2. / 3);
  
  quantum_gate1(target, m, reg);
  
  quantum_delete_matrix(&m);
}

void quantum_u(int target, quantum_reg *reg)
{
  quantum_matrix m = quantum_new_matrix(2, 2);
  
  m.t[0] =  cos(PI / 8);  m.t[1] =  sin(PI / 8);
  m.t[2] = -sin(PI / 8);  m.t[3] =  cos(PI / 8);
  
  quantum_gate1(target, m, reg);
  
  quantum_delete_matrix(&m);
}

void quantum_u_conjt(int target, quantum_reg *reg)
{
  quantum_matrix m = quantum_new_matrix(2, 2);
  
  m.t[0] =  cos(PI / 8);  m.t[1] = -sin(PI / 8);
  m.t[2] =  sin(PI / 8);  m.t[3] =  cos(PI / 8);
  
  quantum_gate1(target, m, reg);
  
  quantum_delete_matrix(&m);
}

void quantum_chadamard(int control, int target, quantum_reg *reg)
{
  quantum_u_conjt(target, reg);
  quantum_cnot(control, target, reg);
  quantum_u(target, reg);
}

quantum_reg quantum_new_spooky()
{
  quantum_reg reg = quantum_new_qureg(0, 2);
  
  quantum_w(1, &reg);
  quantum_chadamard(1, 0, &reg);
  quantum_hadamard(0, &reg);
  
  return reg;
}

int main ()
{
  int i;
  quantum_reg reg;
  MAX_UNSIGNED result;

  srand(time(0));
  
  reg = quantum_new_spooky();
  
  for (i = 0; i < 1000; ++i) {
  
    result = quantum_measure(reg);

    printf("%i ", result);
    
  }
  
  quantum_delete_qureg(&reg);
  
  return 0;
}
