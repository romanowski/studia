#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <quantum.h>

int main ()
{
  int i;
  quantum_reg reg;
  MAX_UNSIGNED result;

  srand(time(0));

  reg = quantum_new_qureg(0, 2);

  quantum_hadamard(0, &reg);

  quantum_hadamard(1, &reg);


  for (i = 0; i < 1000; ++i) {

    result = quantum_measure(reg);
  
    printf("%i ", result);

  }

 return 0;
}
